// pageY 페이지의 위치 스크롤이 생기면 그대로 값은 커진다
// offsetY 요소가 기준이 되어 값이 나옴 요소가 없을 경우 body가 기준이 됨
// clientY 화면에 보이는 값 스크롤이 생겨도 값이 커지지않음 브라우저가 기준이되어 스크롤이 생겨 밑을 찍어도 값은 커지지않음
// screenY 내모니터 크기 스크롤이 발생시 값이 변함

//이미지를 감싼 박스를 들고오고 그걸 움직이게 pageX값을 들고 오기 setInterval을 이용해서 반복적으로 일정하게  왼쪽으로0의 값으로 움직이게 x값이 0이되면 x값에 x의 최댓값을 넣기

// for문을 이용할까?
// const item = document.querySelector(".item");
// const inner = document.querySelector(".inner");
// let targetX = 0;
// let x = 0;

// // item  inner width px
// const itemStyles = getComputedStyle(item);
// const itemWidth = itemStyles.getPropertyValue("width");
// const innerStyle = getComputedStyle(inner);
// const innerWidth = innerStyle.getPropertyValue("width");

// // item inner 位置(X)
// const rect = item.getBoundingClientRect();
// const innerRect = inner.getBoundingClientRect();

// const scrollX = window.pageXOffset;

// let speed = 2;
// const itemPageX = rect.left + scrollX;
// const innerPageX = innerRect.left + scrollX;

// const itemWidthRight = parseInt(itemWidth) + itemPageX + "px";
// const innerWidthRight = parseInt(innerWidth) + innerPageX + "px";

// const inner = document.querySelector(".inner");
// const item = document.querySelector(".item");

// let targetX = 0;
// let x = 0;
// const speed = 2;

// function animateItems() {
//   const innerWidth = inner.offsetWidth;
//   const itemWidth = item.offsetWidth;
//   function moveItems() {
//     targetX -= speed;
//     if (targetX < -itemWidth) {
//       targetX = innerWidth;
//     }
//     item.style.transform = `translateX(${targetX}px)`;
//     requestAnimationFrame(moveItems);
//   }
//   moveItems();
// }
// animateItems();

// const loop = () => {};

// const boxes = document.querySelectorAll("item");

// function setInitialPositions() {
//   boxes.forEach((box) => {
//     box.style.transform = "translateX(0)";
//   });
// }

// setInitialPositions();

const container = document.querySelector(".section2");
const boxes = document.querySelectorAll(".item");
const boxWidth = boxes[0].offsetWidth;

function setInitialPositions() {
  boxes.forEach((box) => {
    box.style.transform = "translateX(0)";
  });
}

function moveBoxes() {
  boxes.forEach((box) => {
    box.style.animation = "moveBox 5s linear infinite";
  });
}

function reloadBoxes() {
  const firstBox = boxes[0];
  const lastBox = boxes[boxes.length - 1];
  const isBoxVisible =
    firstBox.getBoundingClientRect().right <=
    container.getBoundingClientRect().right;

  if (!isBoxVisible) {
    const clonedBox = firstBox.cloneNode(true);
    container.removeChild(firstBox);
    container.appendChild(clonedBox);
    clonedBox.style.transform = `translateX(-${boxWidth}px`;
  }

  setTimeout(reloadBoxes, 0);
}

setInitialPositions();
moveBoxes();
reloadBoxes();
