const stars = document.querySelectorAll(".star");
const result = document.querySelector(".result-star");
const button = document.querySelector("button");
let resultValue = 0;
stars.forEach((star, index) => {
  let value = index + 1;
  star.addEventListener("click", () => {
    reset();
    for (let i = 0; i < value; i++) {
      stars[i].style.color = "gold";
      resultValue++;
    }
    console.log(resultValue);
  });
  const reset = () => {
    resultValue = 0;
    result.style.color = "gray";
    for (let i = 0; i < stars.length; i++) {
      stars[i].style.color = "gray";
    }
  };
});

const stars2 = document.querySelectorAll(".star2");
let resultValue2 = 0;
stars2.forEach((star, index) => {
  let value = index + 1;
  star.addEventListener("click", () => {
    reset();
    for (let i = 0; i < value; i++) {
      stars2[i].style.color = "gold";
      resultValue2++;
    }
    console.log(resultValue2);
  });
  const reset = () => {
    resultValue2 = 0;

    result.style.color = "gray";
    for (let i = 0; i < stars2.length; i++) {
      stars2[i].style.color = "gray";
    }
  };
});

button.addEventListener("click", () => {
  let average = (resultValue + resultValue2) / 2;
  let percentage = ((average / 5) * 100).toFixed(1);
  let left = 100 - percentage;
  result.style.color = "transparent";
  result.style.background = `linear-gradient(to right, gold ${percentage}%, transparent 30%), linear-gradient(to left, gray ${left}%, transparent 30%)`;
  result.style.backgroundClip = "text";
  result.style.webkitBackgroundClip = "text";
});
