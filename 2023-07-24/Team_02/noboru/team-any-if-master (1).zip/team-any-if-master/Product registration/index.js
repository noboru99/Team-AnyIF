// 画面変える
const buttons = document.querySelectorAll(".select button");
const forms = document.querySelectorAll("form");

forms[1].classList.add("hidden");
forms[2].classList.add("hidden");
console.log(buttons);
console.log(forms);
buttons.forEach((button, index) => {
  button.addEventListener("click", () => {
    forms.forEach((content) => content.classList.add("hidden"));
    forms[index].classList.remove("hidden");
  });
});

// img-file upload
const photoInput = document.getElementById("photo-input");
const photoPreview = document.getElementById("photo-preview");

photoInput.addEventListener("change", function (event) {
  const file = event.target.files[0];
  const reader = new FileReader();

  reader.onload = function (event) {
    photoPreview.src = event.target.result;
    photoPreview.style.display = "block";
  };

  reader.readAsDataURL(file);
});
