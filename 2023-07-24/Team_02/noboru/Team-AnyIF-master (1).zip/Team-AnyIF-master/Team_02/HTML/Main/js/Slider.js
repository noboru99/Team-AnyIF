{
  const slide = document.querySelectorAll(".slide");
  const back = document.querySelector(".section1");
  let flag = 0;
  const colors = [
    "rgb(255, 128, 102)",
    "rgb(86, 191, 95)",
    "rgb(77, 166, 255)",
    "rgb(255, 212, 0)",
  ];
  setInterval(() => {
    if (flag == slide.length) flag = 0;

    if (flag != slide.length + 1) {
      slide[flag].classList.remove("Sactive");

      if (flag + 1 === slide.length) {
        slide[0].classList.add("Sactive");
      } else {
        slide[flag + 1].classList.add("Sactive");
      }
      back.style.backgroundColor = colors[flag];
      flag++;
    }
  }, 5000);
}
